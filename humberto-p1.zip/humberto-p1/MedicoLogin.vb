﻿Public Class Form2
    Public Property TelaMedico

    Private Sub BtnEntrar_click(sender As Object, e As EventArgs) Handles BtnEntrar.Click
        If tbDigital.Text = "123456" Then
            TelaMedico = New TelaMedico()
            TelaMedico.Show()

        Else
            MessageBox.Show("login errado")
        End If
    End Sub
End Class