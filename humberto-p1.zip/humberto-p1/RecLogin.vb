﻿Public Class RecLogin
    Public Property TelaRec
    Private Sub BtnEntrar_Click(sender As Object, e As EventArgs) Handles BtnEntrar.Click
        If tbDigital.Text = "1234" Then
            TelaRec = New TelaRec()
            TelaRec.Show()

        Else
            MessageBox.Show("login errado")
        End If
    End Sub
End Class