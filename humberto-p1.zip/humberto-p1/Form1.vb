﻿Imports System.Diagnostics.Eventing.Reader

Public Class Form1
    Public Property MedicoLogin As Form2
    Public Property RecLogin
    Public Property TriagemLogin
    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles BtnLoginMedico.Click



        MedicoLogin = New Form2()
        MedicoLogin.Show()

    End Sub

    Private Sub BtnLoginRec_Click(sender As Object, e As EventArgs) Handles BtnLoginRec.Click
        RecLogin = New RecLogin()
        RecLogin.Show()
    End Sub

    Private Sub BtnLoginTriagem_Click(sender As Object, e As EventArgs) Handles BtnLoginTriagem.Click
        TriagemLogin = New TriagemLogin()
        TriagemLogin.Show()
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class
