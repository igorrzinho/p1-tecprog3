﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Label1 = New Label()
        Label2 = New Label()
        BtnLoginMedico = New Button()
        BtnLoginRec = New Button()
        BtnLoginTriagem = New Button()
        SuspendLayout()
        ' 
        ' Label1
        ' 
        Label1.Anchor = AnchorStyles.Left Or AnchorStyles.Right
        Label1.Font = New Font("Arial Rounded MT Bold", 21.75F, FontStyle.Regular, GraphicsUnit.Point, 0)
        Label1.Location = New Point(0, 0)
        Label1.Name = "Label1"
        Label1.Size = New Size(800, 55)
        Label1.TabIndex = 0
        Label1.Text = "BEM VINDO AO SH"
        Label1.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' Label2
        ' 
        Label2.Anchor = AnchorStyles.Left Or AnchorStyles.Right
        Label2.Font = New Font("Arial Rounded MT Bold", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0)
        Label2.Location = New Point(0, 55)
        Label2.Name = "Label2"
        Label2.Size = New Size(800, 31)
        Label2.TabIndex = 1
        Label2.Text = "Entre como:"
        Label2.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' BtnLoginMedico
        ' 
        BtnLoginMedico.Location = New Point(364, 89)
        BtnLoginMedico.Name = "BtnLoginMedico"
        BtnLoginMedico.Size = New Size(75, 23)
        BtnLoginMedico.TabIndex = 2
        BtnLoginMedico.Text = "Medico"
        BtnLoginMedico.UseVisualStyleBackColor = True
        ' 
        ' BtnLoginRec
        ' 
        BtnLoginRec.Location = New Point(364, 118)
        BtnLoginRec.Name = "BtnLoginRec"
        BtnLoginRec.Size = New Size(75, 23)
        BtnLoginRec.TabIndex = 3
        BtnLoginRec.Text = "Recepcao"
        BtnLoginRec.UseVisualStyleBackColor = True
        ' 
        ' BtnLoginTriagem
        ' 
        BtnLoginTriagem.Location = New Point(364, 147)
        BtnLoginTriagem.Name = "BtnLoginTriagem"
        BtnLoginTriagem.Size = New Size(75, 23)
        BtnLoginTriagem.TabIndex = 4
        BtnLoginTriagem.Text = "Triagem"
        BtnLoginTriagem.UseVisualStyleBackColor = True
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(800, 450)
        Controls.Add(BtnLoginTriagem)
        Controls.Add(BtnLoginRec)
        Controls.Add(BtnLoginMedico)
        Controls.Add(Label2)
        Controls.Add(Label1)
        Name = "Form1"
        Text = "sistema hospital ill"
        ResumeLayout(False)
    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents BtnLoginMedico As Button
    Friend WithEvents BtnLoginRec As Button
    Friend WithEvents BtnLoginTriagem As Button

End Class
