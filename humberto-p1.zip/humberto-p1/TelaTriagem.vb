﻿Public Class TelaTriagem

End Class