﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Descartar substituições de formulário para limpar a lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Exigido pelo Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'OBSERVAÇÃO: o procedimento a seguir é exigido pelo Windows Form Designer
    'Pode ser modificado usando o Windows Form Designer.  
    'Não o modifique usando o editor de códigos.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Label1 = New Label()
        Label2 = New Label()
        tbDigital = New TextBox()
        BtnEntrar = New Button()
        SuspendLayout()
        ' 
        ' Label1
        ' 
        Label1.Font = New Font("Arial Narrow", 14.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label1.Location = New Point(0, 0)
        Label1.Name = "Label1"
        Label1.Size = New Size(800, 45)
        Label1.TabIndex = 0
        Label1.Text = "Login medico"
        Label1.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' Label2
        ' 
        Label2.Font = New Font("Arial Narrow", 14.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label2.Location = New Point(0, 45)
        Label2.Name = "Label2"
        Label2.Size = New Size(800, 45)
        Label2.TabIndex = 1
        Label2.Text = "entre com sua assinatura digital (1-6)"
        Label2.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' tbDigital
        ' 
        tbDigital.Location = New Point(350, 93)
        tbDigital.MaxLength = 6
        tbDigital.Name = "tbDigital"
        tbDigital.PasswordChar = "*"c
        tbDigital.PlaceholderText = "ass digital"
        tbDigital.Size = New Size(100, 23)
        tbDigital.TabIndex = 2
        tbDigital.TextAlign = HorizontalAlignment.Center
        ' 
        ' BtnEntrar
        ' 
        BtnEntrar.Location = New Point(350, 132)
        BtnEntrar.Name = "BtnEntrar"
        BtnEntrar.Size = New Size(100, 23)
        BtnEntrar.TabIndex = 3
        BtnEntrar.Text = "Entrar"
        BtnEntrar.UseVisualStyleBackColor = True
        ' 
        ' Form2
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(800, 450)
        Controls.Add(BtnEntrar)
        Controls.Add(tbDigital)
        Controls.Add(Label2)
        Controls.Add(Label1)
        Name = "Form2"
        Text = "Login medico"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents tbDigital As TextBox
    Friend WithEvents BtnEntrar As Button
End Class
